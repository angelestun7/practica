<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Conectar a la base de datos (ajusta los valores según tu configuración)
    $mysqli = new mysqli("localhost", "usuario_db", "contraseña_db", "mi_base_de_datos");

    // Verificar si la conexión a la base de datos fue exitosa
    if ($mysqli->connect_error) {
        die("Error de conexión: " . $mysqli->connect_error);
    }

    // Consultar la base de datos para verificar la existencia del usuario
    $sql = "SELECT id, contraseña FROM usuarios WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $hashed_password = $row["contraseña"];

        // Verificar la contraseña ingresada con la contraseña almacenada
        if (password_verify($password, $hashed_password)) {
            echo "Inicio de sesión exitoso. Bienvenido.";
        } else {
            echo "Contraseña incorrecta.";
        }
    } else {
        echo
