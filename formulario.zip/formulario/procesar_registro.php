<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Validación de contraseña
    if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/', $password)) {
        echo "La contraseña no cumple con los requisitos de seguridad.";
    } elseif ($password !== $confirm_password) {
        echo "Las contraseñas no coinciden.";
    } else {
        // Aquí puedes procesar y almacenar los datos en una base de datos
        // Por ejemplo, puedes usar MySQL para esto
        // Realiza las operaciones de inserción en la base de datos aquí
        echo "Registro exitoso. Los datos se han almacenado correctamente.";
    }
}
?>
